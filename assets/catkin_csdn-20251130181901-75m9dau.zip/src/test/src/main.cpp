#include "mainwindow.h"
#include  <opencv2/opencv.hpp>
using namespace cv;
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();
    Mat src;
    src=imread("/home/girt/图片/2023-04-24 02-18-41 的屏幕截图.png");
    imshow("1",src);
    waitKey(1);
    return a.exec();
}
